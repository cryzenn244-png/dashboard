# Miracle Cloud Hosting Website

Dark + yellow hosting landing page built with Node.js and Express.

## Run normally

```bash
npm install
npm start
```

Open `http://localhost:3000`.

## Run with Docker

```bash
docker build -t miracle-cloud .
docker run -d --name miracle-cloud -p 3000:3000 miracle-cloud
```

Open `http://localhost:3000`.

## Included

- Responsive dark/yellow hosting design
- Four hosting plans
- Discord community card using the supplied invite
- Hosting panel button
- Node.js + Express
- Docker-ready deployment
- Health endpoint at `/health`

Discord:
https://discord.gg/CB47bFX8YJ

Hosting panel:
https://4tvtpk-6767.csb.app/
